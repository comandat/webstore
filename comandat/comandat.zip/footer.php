<footer class="bg-gray-800 text-gray-300 pt-12 pb-8 mt-16">
    <div class="container mx-auto px-3">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
                <h3 class="text-lg font-semibold text-white mb-4">Comandat.ro</h3>
                <p class="text-sm leading-relaxed">Sursa ta de încredere pentru electronice recondiționate. Oferim
                    calitate superioară la prețuri accesibile, cu garanție completă.</p>
            </div>
            <div>
                <h3 class="text-lg font-semibold text-white mb-4">Cumpărături</h3>
                <ul class="space-y-2 text-sm">
                    <li><a class="hover:text-green-400 transition-colors" href="<?php echo home_url('/products'); ?>">Telefoane Mobile</a>
                    </li>
                    <li><a class="hover:text-green-400 transition-colors" href="<?php echo home_url('/products'); ?>">Laptopuri</a></li>
                    <li><a class="hover:text-green-400 transition-colors" href="<?php echo home_url('/products'); ?>">Tablete</a></li>
                    <li><a class="hover:text-green-400 transition-colors" href="<?php echo home_url('/products'); ?>">Accesorii</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-lg font-semibold text-white mb-4">Suport</h3>
                <ul class="space-y-2 text-sm">
                    <li><a class="hover:text-green-400 transition-colors" href="<?php echo home_url('/contact'); ?>">Contact</a></li>
                    <li><a class="hover:text-green-400 transition-colors" href="#">Garanție</a></li>
                    <li><a class="hover:text-green-400 transition-colors" href="#">Întrebări Frecvente</a></li>
                    <li><a class="hover:text-green-400 transition-colors" href="#">Politica de Retur</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-lg font-semibold text-white mb-4">Rămâi Conectat</h3>
                <p class="text-sm mb-4">Abonează-te pentru a primi oferte speciale și noutăți</p>
                <form class="flex">
                    <input
                        class="flex-1 px-3 py-2 rounded-l-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
                        placeholder="adresa@email.com" type="email" />
                    <button
                        class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-r-lg font-semibold text-sm transition-colors"
                        type="submit">Abonare</button>
                </form>
            </div>
        </div>
        <div class="border-t border-gray-700 pt-6 text-center text-sm">
            <p>© <?php echo date('Y'); ?> Comandat.ro. Toate drepturile rezervate. | Termeni și Condiții | Politica de Confidențialitate
            </p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
